HOOK ARENA · 鉤魂競技場 v0.13.1

先解壓縮，再用最新版 Chrome、Edge 或 Firefox 開啟 Hook-Arena.html。
不需安裝 Node.js。單機可離線；連線對戰需要網路。

操作：滑鼠右鍵移動，Q 出鉤，S 停止，B 商店，Esc / P 選單。
連線：兩方使用 v0.13.1。建立房間後等畫面確認可以加入，再分享 8 位房號。
房主保持分頁在前景。配對暫斷會嘗試重連，加入失敗可重試。
仍無法連線時，按房間視窗的「複製連線資訊」並回報文字。
公共配對及中繼服務可用性仍取決於服務與網路。

網站：https://tommy-ux-cloud.github.io/gpt_game_test/
專案：https://github.com/tommy-ux-cloud/gpt_game_test
