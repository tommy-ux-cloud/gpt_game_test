HOOK ARENA 鉤魂競技場 v0.13

1. 請先解壓縮 ZIP。
2. 使用最新版 Chrome、Edge 或 Firefox 開啟 Hook-Arena.html。
3. 單機模式不需網路；連線對戰需網路，所有人請使用相同版本。
4. 房主按「連線對戰」→「建立房間」，分享 8 位房號給朋友，等朋友加入後再開始。

連線測試版限制：房主需保持分頁在前景，房主離開會結束房間；部分網路需要本版未提供的 TURN 中繼，可能無法直連。

網頁版：https://tommy-ux-cloud.github.io/gpt_game_test/
專案：https://github.com/tommy-ux-cloud/gpt_game_test
